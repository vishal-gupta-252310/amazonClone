// A constants for Routes
export const secureRoute = '/';
export const loginRoute = '/login';
export const dashboardRoute = '/dashboard';
