// Login Constants of the user
export const adminUser = 'vishal';
export const adminPass = 'admin@123';
