// Massage if user Fail to login
const loginFailMsg = 'Username and Password is Wrong';
export default loginFailMsg;
