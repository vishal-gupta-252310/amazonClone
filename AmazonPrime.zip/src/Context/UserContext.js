// imported Package
import { createContext } from 'react';

/**
 *  creating the context constant
 */

const userContext = createContext();

export default userContext;
